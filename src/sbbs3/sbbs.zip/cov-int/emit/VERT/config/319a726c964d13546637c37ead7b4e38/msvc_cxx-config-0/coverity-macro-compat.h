﻿
#if !(defined(_M_IX86) || defined(__coverity_undefine__M_IX86))
#define _M_IX86 600
#endif
#if !(defined(_CPPRTTI) || defined(__coverity_undefine__CPPRTTI))
#define _CPPRTTI 1
#endif
#if !(defined(_INTEGRAL_MAX_BITS) || defined(__coverity_undefine__INTEGRAL_MAX_BITS))
#define _INTEGRAL_MAX_BITS 64
#endif
#if !(defined(_MSC_BUILD) || defined(__coverity_undefine__MSC_BUILD))
#define _MSC_BUILD 0
#endif
#if !(defined(_MSC_EXTENSIONS) || defined(__coverity_undefine__MSC_EXTENSIONS))
#define _MSC_EXTENSIONS 1
#endif
#if !(defined(_MSC_FULL_VER) || defined(__coverity_undefine__MSC_FULL_VER))
#define _MSC_FULL_VER 192829335
#endif
#if !(defined(_MSC_VER) || defined(__coverity_undefine__MSC_VER))
#define _MSC_VER 1928
#endif
#if !(defined(_MSVC_LANG) || defined(__coverity_undefine__MSVC_LANG))
#define _MSVC_LANG 201402L
#endif
#if !(defined(_MT) || defined(__coverity_undefine__MT))
#define _MT 1
#endif
#if !(defined(_M_IX86_FP) || defined(__coverity_undefine__M_IX86_FP))
#define _M_IX86_FP 2
#endif
#if !(defined(_NATIVE_NULLPTR_SUPPORTED) || defined(__coverity_undefine__NATIVE_NULLPTR_SUPPORTED))
#define _NATIVE_NULLPTR_SUPPORTED 1
#endif
#if !(defined(_NATIVE_WCHAR_T_DEFINED) || defined(__coverity_undefine__NATIVE_WCHAR_T_DEFINED))
#define _NATIVE_WCHAR_T_DEFINED 1
#endif
#if !(defined(_WCHAR_T_DEFINED) || defined(__coverity_undefine__WCHAR_T_DEFINED))
#define _WCHAR_T_DEFINED 1
#endif
#if !(defined(_WIN32) || defined(__coverity_undefine__WIN32))
#define _WIN32 1
#endif
#if !(defined(__BOOL_DEFINED) || defined(__coverity_undefine___BOOL_DEFINED))
#define __BOOL_DEFINED 1
#endif
#if !(defined(__STDCPP_DEFAULT_NEW_ALIGNMENT__) || defined(__coverity_undefine___STDCPP_DEFAULT_NEW_ALIGNMENT__))
#define __STDCPP_DEFAULT_NEW_ALIGNMENT__ 8u
#endif
#if !(defined(__STDCPP_THREADS__) || defined(__coverity_undefine___STDCPP_THREADS__))
#define __STDCPP_THREADS__ 1
#endif
#if !(defined(__STDC_HOSTED__) || defined(__coverity_undefine___STDC_HOSTED__))
#define __STDC_HOSTED__ 1
#endif
#if !(defined(__cplusplus) || defined(__coverity_undefine___cplusplus))
#define __cplusplus 199711L
#endif
#if !(defined(__cpp_aggregate_nsdmi) || defined(__coverity_undefine___cpp_aggregate_nsdmi))
#define __cpp_aggregate_nsdmi 201304L
#endif
#if !(defined(__cpp_alias_templates) || defined(__coverity_undefine___cpp_alias_templates))
#define __cpp_alias_templates 200704L
#endif
#if !(defined(__cpp_attributes) || defined(__coverity_undefine___cpp_attributes))
#define __cpp_attributes 200809L
#endif
#if !(defined(__cpp_binary_literals) || defined(__coverity_undefine___cpp_binary_literals))
#define __cpp_binary_literals 201304L
#endif
#if !(defined(__cpp_constexpr) || defined(__coverity_undefine___cpp_constexpr))
#define __cpp_constexpr 201304L
#endif
#if !(defined(__cpp_decltype) || defined(__coverity_undefine___cpp_decltype))
#define __cpp_decltype 200707L
#endif
#if !(defined(__cpp_decltype_auto) || defined(__coverity_undefine___cpp_decltype_auto))
#define __cpp_decltype_auto 201304L
#endif
#if !(defined(__cpp_delegating_constructors) || defined(__coverity_undefine___cpp_delegating_constructors))
#define __cpp_delegating_constructors 200604L
#endif
#if !(defined(__cpp_enumerator_attributes) || defined(__coverity_undefine___cpp_enumerator_attributes))
#define __cpp_enumerator_attributes 201411L
#endif
#if !(defined(__cpp_generic_lambdas) || defined(__coverity_undefine___cpp_generic_lambdas))
#define __cpp_generic_lambdas 201304L
#endif
#if !(defined(__cpp_inheriting_constructors) || defined(__coverity_undefine___cpp_inheriting_constructors))
#define __cpp_inheriting_constructors 200802L
#endif
#if !(defined(__cpp_init_captures) || defined(__coverity_undefine___cpp_init_captures))
#define __cpp_init_captures 201304L
#endif
#if !(defined(__cpp_initializer_lists) || defined(__coverity_undefine___cpp_initializer_lists))
#define __cpp_initializer_lists 200806L
#endif
#if !(defined(__cpp_lambdas) || defined(__coverity_undefine___cpp_lambdas))
#define __cpp_lambdas 200907L
#endif
#if !(defined(__cpp_namespace_attributes) || defined(__coverity_undefine___cpp_namespace_attributes))
#define __cpp_namespace_attributes 201411L
#endif
#if !(defined(__cpp_nsdmi) || defined(__coverity_undefine___cpp_nsdmi))
#define __cpp_nsdmi 200809L
#endif
#if !(defined(__cpp_range_based_for) || defined(__coverity_undefine___cpp_range_based_for))
#define __cpp_range_based_for 200907L
#endif
#if !(defined(__cpp_raw_strings) || defined(__coverity_undefine___cpp_raw_strings))
#define __cpp_raw_strings 200710L
#endif
#if !(defined(__cpp_ref_qualifiers) || defined(__coverity_undefine___cpp_ref_qualifiers))
#define __cpp_ref_qualifiers 200710L
#endif
#if !(defined(__cpp_return_type_deduction) || defined(__coverity_undefine___cpp_return_type_deduction))
#define __cpp_return_type_deduction 201304L
#endif
#if !(defined(__cpp_rtti) || defined(__coverity_undefine___cpp_rtti))
#define __cpp_rtti 199711L
#endif
#if !(defined(__cpp_rvalue_references) || defined(__coverity_undefine___cpp_rvalue_references))
#define __cpp_rvalue_references 200610L
#endif
#if !(defined(__cpp_sized_deallocation) || defined(__coverity_undefine___cpp_sized_deallocation))
#define __cpp_sized_deallocation 201309L
#endif
#if !(defined(__cpp_static_assert) || defined(__coverity_undefine___cpp_static_assert))
#define __cpp_static_assert 200410L
#endif
#if !(defined(__cpp_threadsafe_static_init) || defined(__coverity_undefine___cpp_threadsafe_static_init))
#define __cpp_threadsafe_static_init 200806L
#endif
#if !(defined(__cpp_unicode_characters) || defined(__coverity_undefine___cpp_unicode_characters))
#define __cpp_unicode_characters 200704L
#endif
#if !(defined(__cpp_unicode_literals) || defined(__coverity_undefine___cpp_unicode_literals))
#define __cpp_unicode_literals 200710L
#endif
#if !(defined(__cpp_user_defined_literals) || defined(__coverity_undefine___cpp_user_defined_literals))
#define __cpp_user_defined_literals 200809L
#endif
#if !(defined(__cpp_variable_templates) || defined(__coverity_undefine___cpp_variable_templates))
#define __cpp_variable_templates 201304L
#endif
#if !(defined(__cpp_variadic_templates) || defined(__coverity_undefine___cpp_variadic_templates))
#define __cpp_variadic_templates 200704L
#endif
