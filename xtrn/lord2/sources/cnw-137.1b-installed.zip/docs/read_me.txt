The Gypsy Encampment for LORD2 Ver 7+

Please see the Gypsy.Igm for all Information
about this IGM