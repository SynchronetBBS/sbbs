Before you install the new version of Q's Fortress be sure 
that you uninstall any previous versions of this igm, if you 
already have it, as a precaution against bugs or other errors.