/*
* (C) 2015,2016 Jack Lloyd
*
* Botan is released under the Simplified BSD License (see license.txt)
*/
#include "fuzzers.h"

#include "ecc_helper.h"

void fuzz(std::span<const uint8_t> in) {
   if(in.size() > 2 * 384 / 8) {
      return;
   }
   static const Botan::EC_Group p384("secp384r1");
   return check_ecc_math(p384, in);
}
